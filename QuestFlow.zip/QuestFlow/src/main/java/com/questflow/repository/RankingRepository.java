package com.questflow.repository;

import com.questflow.model.UserRanking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RankingRepository extends JpaRepository<UserRanking, Long> {

}
