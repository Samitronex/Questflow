// src/main/java/com/questflow/repository/UserRewardRedemptionRepository.java
package com.questflow.repository;

import com.questflow.model.UserRewardRedemption;
import com.questflow.model.UserRewardRedemption.UserRewardId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

public interface UserRewardRedemptionRepository extends JpaRepository<UserRewardRedemption, UserRewardId> {

    /** Devuelve todas las redenciones de una recompensa determinada */
    List<UserRewardRedemption> findByReward_Id(Long rewardId);

    /** Devuelve todas las redenciones realizadas por un usuario determinado */
    List<UserRewardRedemption> findByUser_Id(Long userId);

    /**
     * Borra (en cascada) todas las filas de la tabla user_reward_redemptions
     * asociadas a la recompensa cuyo ID es rewardId.
     * Anotamos con @Transactional para que la operación se ejecute en una sola transacción.
     */
    @Transactional
    void deleteByReward_Id(Long rewardId);
}
