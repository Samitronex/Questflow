// src/main/java/com/questflow/controller/RewardController.java
package com.questflow.controller;

import com.questflow.model.Reward;
import com.questflow.service.RewardService;
import com.questflow.service.UserService;
import com.questflow.service.UserRewardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/rewards")
public class RewardController {

    private final RewardService rewardService;
    private final UserService userService;
    private final UserRewardService userRewardService;

    public RewardController(
            RewardService rewardService,
            UserService userService,
            UserRewardService userRewardService
    ) {
        this.rewardService = rewardService;
        this.userService = userService;
        this.userRewardService = userRewardService;
    }

    /**
     * GET /api/rewards
     * Lista todas las recompensas disponibles para canjear.
     */
    @GetMapping
    public ResponseEntity<List<Reward>> all() {
        List<Reward> list = rewardService.listAll();
        return ResponseEntity.ok(list);
    }

    /**
     * POST /api/rewards/{rewardId}/redeem
     * Canjea la recompensa {rewardId} para el usuario autenticado.
     */
    @PostMapping("/{rewardId}/redeem")
    public ResponseEntity<Void> redeem(
            @PathVariable Long rewardId,
            Principal principal
    ) {
        // 1) Obtiene el username del principal
        String username = principal.getName();
        // 2) Obtener el UserDTO (o User) completo para extraer su ID
        Long userId = userService.findByUsername(username).getId();
        // 3) Llamar al servicio que realiza el canje y descuenta monedas
        userRewardService.redeemReward(userId, rewardId);
        return ResponseEntity.noContent().build();
    }
}
