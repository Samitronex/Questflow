// src/main/java/com/questflow/controller/admin/AdminRewardController.java
package com.questflow.controller.admin;

import com.questflow.model.Reward;
import com.questflow.service.RewardService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/rewards")
@PreAuthorize("hasRole('ADMIN')")
public class AdminRewardController {

    private final RewardService rewardService;

    public AdminRewardController(RewardService rewardService) {
        this.rewardService = rewardService;
    }

    /** 1) GET /api/admin/rewards → lista todas las recompensas */
    @GetMapping
    public ResponseEntity<List<Reward>> listAll() {
        return ResponseEntity.ok(rewardService.listAll());
    }

    /** 2) POST /api/admin/rewards → crea una nueva recompensa */
    @PostMapping
    public ResponseEntity<Reward> create(@RequestBody Reward payload) {
        Reward saved = rewardService.create(payload);
        return ResponseEntity.ok(saved);
    }

    /** 3) PUT /api/admin/rewards/{id} → modifica una recompensa */
    @PutMapping("/{id}")
    public ResponseEntity<Reward> update(
            @PathVariable Long id,
            @RequestBody Reward payload
    ) {
        Reward updated = rewardService.update(id, payload);
        return ResponseEntity.ok(updated);
    }

    /** 4) DELETE /api/admin/rewards/{id} → borra una recompensa*/
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        rewardService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
