// src/main/java/com/questflow/service/impl/RewardServiceImpl.java
package com.questflow.service.impl;

import com.questflow.model.Reward;
import com.questflow.repository.RewardRepository;
import com.questflow.service.RewardService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class RewardServiceImpl implements RewardService {

    private final RewardRepository rewardRepo;

    public RewardServiceImpl(RewardRepository rewardRepo) {
        this.rewardRepo = rewardRepo;
    }

    @Override
    public List<Reward> listAll() {
        return rewardRepo.findAll();
    }

    @Override
    public Reward create(Reward payload) {
        // payload.name, payload.description, payload.cost → debe rellenar coins_cost
        return rewardRepo.save(payload);
    }

    @Override
    public Reward update(Long id, Reward payload) {
        Reward existing = rewardRepo.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Recompensa no encontrada: " + id));
        existing.setName(payload.getName());
        existing.setDescription(payload.getDescription());
        existing.setCost(payload.getCost());
        return rewardRepo.save(existing);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (!rewardRepo.existsById(id)) {
            throw new IllegalArgumentException("Recompensa no existe: " + id);
        }
        rewardRepo.deleteById(id);
    }

    @Override
    public Reward findById(Long id) {
        return rewardRepo.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Recompensa no encontrada: " + id));
    }
}
