package com.questflow.service.impl;

import com.questflow.dto.UserRankingDto;
import com.questflow.model.User;
import com.questflow.repository.UserRepository;
import com.questflow.service.RankingService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RankingServiceImpl implements RankingService {

    private final UserRepository userRepo;

    public RankingServiceImpl(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserRankingDto> listAll() {
        // 1. Recuperar todos los usuarios
        List<User> allUsers = userRepo.findAll();

        // 2. Ordenar por XP decreciente
        return allUsers.stream()
            .sorted(Comparator.comparingInt(User::getXp).reversed())
            .map(u -> new UserRankingDto(
                    u.getId(),
                    u.getUsername(),
                    u.getLevel(),
                    u.getXp()
                ))
            .collect(Collectors.toList());
    }
}
