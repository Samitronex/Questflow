// src/main/java/com/questflow/service/impl/UserRewardRedemptionServiceImpl.java
package com.questflow.service.impl;

import com.questflow.model.UserRewardRedemption;
import com.questflow.repository.UserRewardRedemptionRepository;
import com.questflow.service.UserRewardRedemptionService;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserRewardRedemptionServiceImpl implements UserRewardRedemptionService {

    private final UserRewardRedemptionRepository urRepo;

    public UserRewardRedemptionServiceImpl(UserRewardRedemptionRepository urRepo) {
        this.urRepo = urRepo;
    }

    /** Busca todos los canjes para la recompensa cuyo ID es rewardId */
    @Override
    public List<UserRewardRedemption> findByReward(Long rewardId) {
        return urRepo.findByReward_Id(rewardId);
    }

    /** Busca todos los canjes realizados por el usuario cuyo ID es userId */
    @Override
    public List<UserRewardRedemption> findByUser(Long userId) {
        return urRepo.findByUser_Id(userId);
    }
}
