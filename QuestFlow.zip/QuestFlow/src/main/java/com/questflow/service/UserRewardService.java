// src/main/java/com/questflow/service/UserRewardService.java
package com.questflow.service;

import com.questflow.dto.UserRewardDto;

import java.util.List;

public interface UserRewardService {

    /**
     * Registra el canje de la recompensa (descuenta monedas al usuario y guarda el registro).
     */
    void redeemReward(Long userId, Long rewardId);

    /**
     * Devuelve todos los canjes, para que el admin los vea.
     */
    List<UserRewardDto> findAllRedeemed();
}
