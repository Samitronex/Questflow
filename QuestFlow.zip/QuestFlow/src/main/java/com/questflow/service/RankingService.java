package com.questflow.service;

import com.questflow.dto.UserRankingDto;
import java.util.List;

public interface RankingService {
    /**
   
     */
    List<UserRankingDto> listAll();
}
