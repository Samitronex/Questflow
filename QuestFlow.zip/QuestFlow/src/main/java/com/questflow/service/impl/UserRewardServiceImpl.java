// src/main/java/com/questflow/service/impl/UserRewardServiceImpl.java
package com.questflow.service.impl;

import com.questflow.dto.UserRewardDto;
import com.questflow.model.Reward;
import com.questflow.model.User;
import com.questflow.model.UserRewardRedemption;
import com.questflow.repository.RewardRepository;
import com.questflow.repository.UserRepository;
import com.questflow.repository.UserRewardRedemptionRepository;
import com.questflow.service.UserRewardService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserRewardServiceImpl implements UserRewardService {

    private final UserRewardRedemptionRepository urRepo;
    private final UserRepository userRepo;
    private final RewardRepository rewardRepo;

    public UserRewardServiceImpl(
            UserRewardRedemptionRepository urRepo,
            UserRepository userRepo,
            RewardRepository rewardRepo
    ) {
        this.urRepo = urRepo;
        this.userRepo = userRepo;
        this.rewardRepo = rewardRepo;
    }

    /**
     *  1) Busca usuario por ID
     *  2) Busca recompensa por ID
     *  3) Verifica que el usuario tenga suficientes monedas
     *  4) Descuenta monedas en la entidad User
     *  5) Crea un registro en user_reward_redemptions
     */
    @Override
    @Transactional
    public void redeemReward(Long userId, Long rewardId) {
        // 1) Buscar usuario
        User user = userRepo.findById(userId)
            .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado: " + userId));
        // 2) Buscar recompensa
        Reward reward = rewardRepo.findById(rewardId)
            .orElseThrow(() -> new IllegalArgumentException("Recompensa no encontrada: " + rewardId));
        // 3) Verificar monedas
        if (user.getCoins() < reward.getCost()) {
            throw new IllegalStateException("No hay suficientes monedas para canjear");
        }
        // 4) Descontar monedas y guardar usuario
        user.setCoins(user.getCoins() - reward.getCost());
        userRepo.save(user);
        // 5) Crear el canje
        UserRewardRedemption ur = new UserRewardRedemption(user, reward);
        ur.setRedeemedAt(LocalDateTime.now());
        urRepo.save(ur);
    }

    /**
     * Devuelve todos los canjes (user_reward_redemptions) en forma de DTO,
     * para que el administrador los muestre.
     */
    @Override
    @Transactional(readOnly = true)
    public List<UserRewardDto> findAllRedeemed() {
        return urRepo.findAll()
                .stream()
                .map(ur -> {
                    UserRewardDto dto = new UserRewardDto();
                    dto.setUserId(ur.getUser().getId());
                    dto.setUsername(ur.getUser().getUsername());
                    dto.setRewardId(ur.getReward().getId());
                    dto.setRewardName(ur.getReward().getName());
                    dto.setRedeemedAt(ur.getRedeemedAt());
                    return dto;
                })
                .collect(Collectors.toList());
    }
}
