// src/main/java/com/questflow/service/RewardService.java
package com.questflow.service;

import com.questflow.model.Reward;
import java.util.List;

public interface RewardService {

    /** 1) Listar todas las recompensas */
    List<Reward> listAll();

    /** 2) Crear (o guardar) una nueva recompensa */
    Reward create(Reward payload);

    /** 3) Actualizar una recompensa existente */
    Reward update(Long id, Reward payload);

    /**
     * 4) Borrar una recompensa. 
     *    Antes de eliminarla de “rewards”, debe eliminar en cascada todas las redenciones
     *    asociadas a esa recompensa en la tabla user_reward_redemptions.
     */
    void delete(Long id);

    /** 5) Buscar por ID (opcional, para uso interno) */
    Reward findById(Long id);
}
