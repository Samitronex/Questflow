// src/main/java/com/questflow/service/UserRewardRedemptionService.java
package com.questflow.service;

import com.questflow.model.UserRewardRedemption;
import java.util.List;

public interface UserRewardRedemptionService {
    /** Encuentra todas las redenciones para una recompensa específica */
    List<UserRewardRedemption> findByReward(Long rewardId);

    /** Encuentra todas las redenciones que ha hecho un usuario */
    List<UserRewardRedemption> findByUser(Long userId);
}
