// src/main/java/com/questflow/model/UserRewardRedemption.java
package com.questflow.model;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Representa el canje de una Recompensa por parte de un Usuario.
 * La clave primaria es compuesta (user_id, reward_id).
 */
@Entity
@Table(name = "user_reward_redemptions")
public class UserRewardRedemption implements Serializable {

    @Embeddable
    public static class UserRewardId implements Serializable {
        @Column(name = "user_id")
        private Long userId;

        @Column(name = "reward_id")
        private Long rewardId;

        public UserRewardId() {}

        public UserRewardId(Long userId, Long rewardId) {
            this.userId = userId;
            this.rewardId = rewardId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof UserRewardId)) return false;
            UserRewardId that = (UserRewardId) o;
            return this.userId.equals(that.userId) && this.rewardId.equals(that.rewardId);
        }

        @Override
        public int hashCode() {
            return java.util.Objects.hash(userId, rewardId);
        }

        public Long getUserId() {
            return userId;
        }
        public void setUserId(Long userId) {
            this.userId = userId;
        }
        public Long getRewardId() {
            return rewardId;
        }
        public void setRewardId(Long rewardId) {
            this.rewardId = rewardId;
        }
    }

    @EmbeddedId
    private UserRewardId id;

    @MapsId("userId")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @MapsId("rewardId")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "reward_id", nullable = false)
    private Reward reward;

    @Column(name = "redeemed_at", nullable = false)
    private LocalDateTime redeemedAt;

    public UserRewardRedemption() {}

    public UserRewardRedemption(User user, Reward reward) {
        this.id = new UserRewardId(user.getId(), reward.getId());
        this.user = user;
        this.reward = reward;
    }

    public UserRewardId getId() {
        return id;
    }
    public void setId(UserRewardId id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }

    public Reward getReward() {
        return reward;
    }
    public void setReward(Reward reward) {
        this.reward = reward;
    }

    public LocalDateTime getRedeemedAt() {
        return redeemedAt;
    }
    public void setRedeemedAt(LocalDateTime redeemedAt) {
        this.redeemedAt = redeemedAt;
    }
}
