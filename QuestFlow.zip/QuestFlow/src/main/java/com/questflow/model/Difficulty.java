package com.questflow.model;

public enum Difficulty {
  EASY,
  MEDIUM,
  HARD
}
