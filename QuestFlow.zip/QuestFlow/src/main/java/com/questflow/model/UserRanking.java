package com.questflow.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

// Si tu tabla en BD se llama “user_rankings”, apunta aquí:
@Entity
@Table(name = "user_rankings")
public class UserRanking {

    @Id
    private Long user_id;     
    private String username;
    private int level;
    private int xp_total;

    // ––––– Getters y setters –––––

    public Long getUser_id() {
        return user_id;
    }
    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public int getLevel() {
        return level;
    }
    public void setLevel(int level) {
        this.level = level;
    }

    public int getXp_total() {
        return xp_total;
    }
    public void setXp_total(int xp_total) {
        this.xp_total = xp_total;
    }
}
