package com.questflow.dto;

/**
 * Solo contiene los datos que queremos enviar al frontend:
 *   userId, username, level e xpTotal.
 */
public class UserRankingDto {
    private Long userId;
    private String username;
    private int level;
    private int xpTotal;

    public UserRankingDto() {}

    public UserRankingDto(Long userId, String username, int level, int xpTotal) {
        this.userId   = userId;
        this.username = username;
        this.level    = level;
        this.xpTotal  = xpTotal;
    }

    // ─────────────────── Getters / Setters ───────────────────

    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public int getLevel() {
        return level;
    }
    public void setLevel(int level) {
        this.level = level;
    }

    public int getXpTotal() {
        return xpTotal;
    }
    public void setXpTotal(int xpTotal) {
        this.xpTotal = xpTotal;
    }
}
