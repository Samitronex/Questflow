// src/main/java/com/questflow/dto/UserRewardDto.java
package com.questflow.dto;

import com.questflow.model.UserRewardRedemption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

public class UserRewardDto {

    private Long userId;
    private String username;

    // ─── Campos que faltaban ─────────────────────────────────────────────────────
    private Long rewardId;
    private String rewardName;
    // ──────────────────────────────────────────────────────────────────────────────

    private LocalDateTime redeemedAt;

    public UserRewardDto() { }

    public UserRewardDto(Long userId, String username, Long rewardId, String rewardName, LocalDateTime redeemedAt) {
        this.userId = userId;
        this.username = username;
        this.rewardId = rewardId;
        this.rewardName = rewardName;
        this.redeemedAt = redeemedAt;
    }

    // ─── Getters & Setters ────────────────────────────────────────────────────────

    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public Long getRewardId() {
        return rewardId;
    }
    public void setRewardId(Long rewardId) {
        this.rewardId = rewardId;
    }

    public String getRewardName() {
        return rewardName;
    }
    public void setRewardName(String rewardName) {
        this.rewardName = rewardName;
    }

    public LocalDateTime getRedeemedAt() {
        return redeemedAt;
    }
    public void setRedeemedAt(LocalDateTime redeemedAt) {
        this.redeemedAt = redeemedAt;
    }
    // ──────────────────────────────────────────────────────────────────────────────

    /**
     * Convierte una lista de UserRewardRedemption (entidad) a lista de UserRewardDto
     */
    public static List<UserRewardDto> fromRedemptions(List<UserRewardRedemption> list) {
        return list.stream().map(r ->
            new UserRewardDto(
                r.getUser().getId(),
                r.getUser().getUsername(),
                r.getReward().getId(),
                r.getReward().getName(),
                r.getRedeemedAt()
            )
        ).collect(Collectors.toList());
    }
}
