// src/services/api.js
import axios from 'axios';

const API = axios.create({
  baseURL: '/api',              
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true       
});

// Usuarios
export async function register({ username, email, password, avatarClass }) {
  const { data } = await API.post('/users', { username, email, password, avatarClass });
  return data;
}
export async function authenticate({ username, password }) {
  const { data } = await API.post('/users/authenticate', { username, password });
  return data;
}
export async function fetchUser(userId) {
  const { data } = await API.get(`/users/${userId}`);
  return data;
}

// Misiones
export async function fetchMissions(userId) {
  const { data } = await API.get(`/users/${userId}/missions`);
  return data;
}
export async function completeMission(userId, missionId) {
  await API.post(`/users/${userId}/missions/${missionId}/complete`);
}

// Recompensas
export async function fetchRewards(userId) {
  const { data } = await API.get(`/users/${userId}/rewards`);
  return data;
}
export async function redeemReward(userId, rewardId) {
  await API.post(`/users/${userId}/rewards/${rewardId}/redeem`);
}

// Rankings
export async function fetchRankings(groupId) {
  const { data } = await API.get(`/groups/${groupId}/rankings`);
  return data;
}

export default API;
