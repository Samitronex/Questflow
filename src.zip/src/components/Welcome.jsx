// src/components/Welcome.jsx
import React from 'react';
import { Link } from 'react-router-dom';

export default function Welcome() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-purple-600 to-blue-500">
      <h1 className="text-4xl text-white mb-8">QuestFlow</h1>
      <div className="space-x-4">
        <Link
          to="/login"
          className="px-6 py-3 bg-white text-purple-700 font-bold rounded shadow hover:bg-gray-100"
        >
          Iniciar Sesión
        </Link>
        <Link
          to="/signup"
          className="px-6 py-3 bg-white text-purple-700 font-bold rounded shadow hover:bg-gray-100"
        >
          Registrarse
        </Link>
      </div>
    </div>
  );
}
