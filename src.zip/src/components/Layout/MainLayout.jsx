// src/components/Layout/MainLayout.jsx
import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';

export default function MainLayout({ user, onLogout }) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="w-full bg-gray-800 text-white px-6 py-3 flex items-center">
        <nav className="flex-1 flex justify-center space-x-12 text-lg">
          {['Perfil','Misiones','Recompensas','rankings'].map(path => (
            <NavLink
              key={path}
              to={`/${path}`}
              className={({ isActive }) =>
                `px-2 py-1 rounded ${isActive ? 'bg-gray-700' : 'hover:bg-gray-700'}`
              }
            >
              {path.charAt(0).toUpperCase() + path.slice(1)}
            </NavLink>
          ))}
          {user.role === 'Admin' && (
            <NavLink
              to="/admin"
              className={({ isActive }) =>
                `px-2 py-1 rounded ${isActive ? 'bg-gray-700' : 'hover:bg-gray-700'}`
              }
            >
              Admin
            </NavLink>
          )}
        </nav>
        <button
          onClick={onLogout}
          className="ml-auto bg-red-600 hover:bg-red-700 px-4 py-1 rounded text-sm"
        >
          Cerrar sesión
        </button>
      </header>
      <main className="flex-1 bg-[#11132f] text-white p-6">
        <Outlet />
      </main>
    </div>
  );
}
