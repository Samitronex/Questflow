// src/components/pages/Auth/Register.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { register } from '../../../services/api';

import guerrero from '../../../assets/avatars/guerrero.png';
import mago     from '../../../assets/avatars/mago.png';
import soporte  from '../../../assets/avatars/soporte.png';
import asesino  from '../../../assets/avatars/asesino.png';

const avatarOptions = {
  Asesino:  asesino,
  Mago:     mago,
  Soporte:  soporte,
  Guerrero: guerrero
};

export default function Register({ onRegister }) {
  const [username, setUsername]     = useState('');
  const [email,    setEmail]        = useState('');
  const [password, setPassword]     = useState('');
  const [avatarClass, setAvatar]    = useState('Asesino');
  const [error,    setError]        = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const user = await register({ username, email, password, avatarClass });
      onRegister(user);
      navigate('/profile');
    } catch (err) {
      console.error(err);
      setError('No se pudo crear la cuenta, inténtalo de nuevo');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900">
      <div className="w-full max-w-md bg-gray-800 rounded-xl shadow-lg p-8 space-y-6">
        <h2 className="text-3xl font-extrabold text-white text-center">Crear Cuenta</h2>
        {error && <p className="text-red-400 text-sm text-center">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Usuario */}
          <div>
            <label htmlFor="username" className="block text-gray-300 mb-1">Usuario</label>
            <input
              id="username"
              className="w-full px-4 py-2 rounded-md bg-gray-700 text-white"
              value={username}
              onChange={e => setUsername(e.target.value)}
              required
            />
          </div>
          {/* Email */}
          <div>
            <label htmlFor="email" className="block text-gray-300 mb-1">Email</label>
            <input
              id="email"
              type="email"
              className="w-full px-4 py-2 rounded-md bg-gray-700 text-white"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
          </div>
          {/* Contraseña */}
          <div>
            <label htmlFor="password" className="block text-gray-300 mb-1">Contraseña</label>
            <input
              id="password"
              type="password"
              className="w-full px-4 py-2 rounded-md bg-gray-700 text-white"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
          </div>
          {/* Avatar / Rol */}
          <div>
            <p className="text-gray-300 mb-2">Elige tu rol</p>
            <div className="grid grid-cols-2 gap-4">
              {Object.entries(avatarOptions).map(([role, src]) => (
                <div
                  key={role}
                  onClick={() => setAvatar(role)}
                  className={`
                    cursor-pointer p-2 rounded-xl bg-gray-700 flex flex-col items-center
                    ${avatarClass === role
                      ? 'border-2 border-yellow-400 ring-2 ring-yellow-500'
                      : 'border-transparent hover:ring-1 hover:ring-gray-500'}
                  `}
                >
                  <img src={src} alt={role} className="w-16 h-16 object-contain" />
                  <span className="mt-2 text-gray-200">{role}</span>
                </div>
              ))}
            </div>
          </div>
          {/* Enviar */}
          <button
            type="submit"
            className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md"
          >
            Registrarme
          </button>
        </form>
        <p className="text-gray-400 text-center text-sm">
          ¿Ya tienes cuenta?{' '}
          <button onClick={() => navigate('/login')} className="text-indigo-400 hover:underline">
            Inicia sesión
          </button>
        </p>
      </div>
    </div>
  );
}
