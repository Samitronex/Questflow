// src/components/pages/Auth/Login.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authenticate } from '../../../services/api';

export default function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error,    setError]    = useState(null);
  const navigate = useNavigate();

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const user = await authenticate({ username, password });
      onLogin(user);
      navigate('/profile');
    } catch {
      setError('Usuario o contraseña incorrectos');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900">
      <div className="w-full max-w-md bg-gray-800 rounded-xl shadow-lg p-8 space-y-6">
        <h2 className="text-3xl font-extrabold text-white text-center">Iniciar Sesión</h2>
        {error && <p className="text-red-400 text-sm text-center">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-gray-300 mb-1">Usuario</label>
            <input
              className="w-full px-4 py-2 rounded-md bg-gray-700 text-white"
              value={username}
              onChange={e => setUsername(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="block text-gray-300 mb-1">Contraseña</label>
            <input
              type="password"
              className="w-full px-4 py-2 rounded-md bg-gray-700 text-white"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md"
          >
            Entrar
          </button>
        </form>
        <p className="text-gray-400 text-center text-sm">
          ¿No tienes cuenta?{' '}
          <button onClick={() => navigate('/register')} className="text-indigo-400 hover:underline">
            Regístrate
          </button>
        </p>
      </div>
    </div>
  );
}
