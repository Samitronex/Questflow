import React, { useEffect, useState } from 'react'
import { fetchMissions, completeMission } from '../../../services/api'
import coinIcon from '../../../assets/icons/coin.png'
import xpIcon   from '../../../assets/icons/xp.png'

export default function MissionsBoard({ user }) {
  const [missions, setMissions] = useState([])

  useEffect(() => {
    fetchMissions(user.id)
      .then(setMissions)
      .catch(console.error)
  }, [user.id])

  const handleComplete = async (missionId) => {
    try {
      await completeMission(user.id, missionId)
      const updated = await fetchMissions(user.id)
      setMissions(updated)
    } catch (err) {
      console.error(err)
    }
  }

  return (
    <div className="w-full px-8 py-10">
      <h1 className="text-3xl font-bold mb-8 text-center">Mis Misiones</h1>
      <ul className="space-y-6">
        {missions.map(m => (
          <li
            key={m.id}
            className="w-full bg-[#313a65] p-6 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center"
          >
            <div className="flex-1">
              <h2 className="text-white text-xl font-semibold">{m.title}</h2>
              <p className="text-gray-300 mt-1">{m.description}</p>
              <div className="flex items-center gap-8 text-gray-400 text-sm mt-4">
                <span className="flex items-center gap-2">
                  <img src={xpIcon} alt="XP" className="w-5 h-5" />
                  <span className="font-medium">{m.xp_reward} XP</span>
                </span>
                <span className="flex items-center gap-2">
                  <img src={coinIcon} alt="Monedas" className="w-5 h-5" />
                  <span className="font-medium">{m.coins_reward}</span>
                </span>
              </div>
            </div>
            <button
              onClick={() => handleComplete(m.id)}
              className="mt-6 sm:mt-0 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg"
            >
              Completar
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}
