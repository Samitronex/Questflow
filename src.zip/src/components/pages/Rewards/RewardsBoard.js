import React, { useEffect, useState } from 'react'
import { fetchRewards, redeemReward } from '../../../services/api'
import coinIcon from '../../../assets/icons/coin.png'

export default function RewardsBoard({ user }) {
  const [rewards, setRewards] = useState([])

  useEffect(() => {
    fetchRewards(user.id)
      .then(setRewards)
      .catch(console.error)
  }, [user.id])

  const handleRedeem = async (rewardId) => {
    try {
      await redeemReward(user.id, rewardId)
      // puedes recargar perfil / lista si quieres
    } catch (err) {
      console.error(err)
    }
  }

  return (
    <div className="w-full px-8 py-10">
      <h1 className="text-3xl font-bold mb-8 text-center">Recompensas</h1>
      <ul className="space-y-6">
        {rewards.map(r => (
          <li
            key={r.id}
            className="w-full bg-[#313a65] p-6 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center"
          >
            <div className="flex-1">
              <h2 className="text-white text-xl font-semibold">{r.name}</h2>
              <p className="text-gray-300 mt-1">{r.description}</p>
              <div className="flex items-center text-gray-400 text-sm mt-4">
                <img src={coinIcon} alt="Monedas" className="w-5 h-5 mr-2" />
                Precio: <span className="font-medium ml-1">{r.coins_cost}</span>
              </div>
            </div>
            <button
              onClick={() => handleRedeem(r.id)}
              className="mt-6 sm:mt-0 bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg"
            >
              Canjear
            </button>
          </li>
        ))}
      </ul>
    </div>
  )
}
